#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#define BLOCK_SIZE      (4 * 1024)
#define PERIPHERAL_BASE 0x20000000      // PI0
//#define PERIPHERAL_BASE       0x7E000000  // PI2
#define GPIO_BASE       PERIPHERAL_BASE + 0x00200000

typedef struct {
        unsigned long           gpio_base;
        int                     memory_fd;
        void                    *map;
        volatile unsigned int   *addr;
} rpi_gpio;

int GX[8] = {  2,  3,  4, 17, 18, 27, 22, 23 };
int GY[8] = { 24, 25, 12,  5,  6, 13, 19,  0 };
char FPtn[64*1024];

int MapGPIO(rpi_gpio *gpio)
{
        gpio->memory_fd = open("/dev/mem", O_RDWR|O_SYNC );
        if(gpio->memory_fd < 0) {
                perror("Failed to open /dev/mem\n");
                return -1;
        }
        gpio->map = mmap( NULL, BLOCK_SIZE, PROT_READ|PROT_WRITE,
                        MAP_SHARED, gpio->memory_fd, gpio->gpio_base );
        if(gpio->map == MAP_FAILED){
                perror("cannot mmap\n");
                return -2;
        }
        gpio->addr = (volatile unsigned int *)gpio->map;
        return 0;
}

void UnmapGPIO(rpi_gpio *gpio)
{
        munmap(gpio->map, BLOCK_SIZE);
        close(gpio->memory_fd);
}

void InitGPIO(rpi_gpio *gpio,unsigned long GpioNo, unsigned long data)
{
        unsigned long gpio_addr,gpio_write_data,bit_shift;
        gpio_addr = (GpioNo/10)*4 + (unsigned long)gpio->addr;
        bit_shift = (GpioNo%10)*3;
        gpio_write_data = *((unsigned long *)gpio_addr);
        gpio_write_data &= ~(0x7UL << bit_shift);
        gpio_write_data |= data << bit_shift;
        *(unsigned long *)gpio_addr = gpio_write_data;
}
void OutOnGPIO(rpi_gpio *gpio,unsigned long GpioNo)
{
        *(gpio->addr + 7) = 1 << GpioNo;
}

void OutOffGPIO(rpi_gpio *gpio,unsigned long GpioNo)
{
        *(gpio->addr + 10) = 1 << GpioNo;
}

int FontInit(void)
{
        FILE *fp;
        int i,j,k;

        if ( (fp=fopen("./MSKG.FNT","rb") )==NULL){
                fprintf(stderr,"Cannot found fontfile\n");
                return -1;
        }
        fread(FPtn,sizeof(FPtn),1,fp);
        fclose(fp);

        // SPACE
        j= (' ' - '0' + 0xDB)*8;
        for (i=j; i< j+8; i++) FPtn[i] = 0;
        // ':'->0x16
        j= (':' - '0' + 0xDB)*8;
        k= 0x16*8;
        for (i=j; i< j+8; i++) FPtn[i] = FPtn[k++];
        // '/' ->0x2e
        j= ('/' - '0' + 0xDB)*8;
        k= 0x2e*8;
        for (i=j; i< j+8; i++) FPtn[i] = FPtn[k++];
        return 0;
}

void write_font(rpi_gpio *p_gpio,char *p_dat,int offset)
{
        int y,p,p2,code1,code2,code;
        int px,py,i;
        p = offset / 8;
        p2 = offset % 8;
        code1 = ( (int)p_dat[p] - '0' + 0xDB ) * 8;
        code2 = ( (int)p_dat[p+1] - '0' + 0xDB ) * 8;

        code = code1 + p2;
        px = 7;
        py = 0;
        for (i=0; i<8; i++){
                OutOnGPIO(p_gpio,GX[px]);
                for(y=7; y>=0; y--){
                        if(FPtn[code] & (1<<y)){
                                OutOnGPIO(p_gpio,GY[py]);
                        } else {
                                OutOffGPIO(p_gpio,GY[py]);
                        }
                        py++;
                }
                if(code == (code1+8) ){
                        code = code2;
                        code1 = 0;
                } else {
                        code ++;
                }
                usleep(200);
                OutOffGPIO(p_gpio,GX[px]);
                py = 0;
                px--;
        }
}

/*
 * Main routine
 */
int main(int argc, char **argv)
{
        rpi_gpio gpio = {GPIO_BASE};
        int map_status;
        int i,j;
        int x,y;
        time_t tt;
        struct tm *ptm;
        char disp_buf[80];

        map_status = MapGPIO(&gpio);
        if(map_status){
                printf("Error End\n");
                return map_status;
        }
        for (i=0; i<29;i++){
                InitGPIO(&gpio,i,1);
                OutOffGPIO(&gpio,i);
        }
        if( FontInit() <0 ){
                return -1;
        }
        for (i=0; i<29;i++){
                OutOffGPIO(&gpio,i);
        }
        /*
         * Local Time Display
         */
        while(1){
                time(&tt);
                ptm = localtime(&tt);
                sprintf(disp_buf," %u/%u %02u:%02u  ",
                        ptm->tm_mon+1, ptm->tm_mday,
                        ptm->tm_hour,ptm->tm_min);
                j = (strlen(disp_buf) -1)*8;
                for(x=0; x<j; x++){
                        for(i=0; i<50; i++)  write_font(&gpio, disp_buf, x);
                }
        }
        return 0;
}
